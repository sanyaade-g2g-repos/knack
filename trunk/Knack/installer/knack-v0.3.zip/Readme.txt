  -----------
    Knack
  -----------
  by Gerosa Riccardo a.k.a. h3


* THIS SOFTWARE IS FREEWARE AND DOESN'T CONTAIN ANY SPYWARE

You can freely use and distribute it, but you can't distribute
modified copies.

* INTRODUCTION

Knack is an experimental software synthesizer coded in C#, 
it is modular and at the moment it does Additive and FM synthesis.
This software uses a MIDI input (so you should have a MIDI keyboard 
to use it) and a Managed DirectX 9 output.

* INSTALLATION

Knack should work under Windows XP or later.
This program requires the following components installed
in the following order:

   1. The Microsoft .NET Framework Runtime v.1.1 or later
   
   2. The Microsoft DirectX 9 Runtime or later, installed
   using the following command line: 
   DXSetup.exe /InstallManagedDX
   (you have to use the full version of the DirectX installer,
   not the version which downloads the components from the web)

If you did install the .NET Runtime after the DirectX Runtime, 
then reinstall the DirectX Runtime (the Managed DirectX
libraries can't be installed if the .NET Framework is not 
already present).
These Windows components are available for free on the 
Microsoft web site and through Windows Update.
When you have installed these components you can simply unzip 
and run the program, it's very small in size and it does not 
need installation.

* FEATURES

Stereo synthesis and mixing with floating point 32bit precision.
Different FM operators and waveforms. A stereo delay effect 
with feedback. A random note generator. XML based file format.
This project is in a pre-alpha stage, you can 
already test it but it's not very usable cause it's not 
finished yet and it's still under developement.
If you test it you can give me some feedback writing a comment 
in my weblog, that would be very appreciated.

* DISCLAIMER OF WARRANTY

This software and the accompanying files are presented "AS IS" and without 
warranties as to performance or merchantability or any other warranties 
wether expressed or implied.

---------------------------------------------------------------------------
� 2004 Gerosa Riccardo a.k.a. h3, All rights reserved.
Knack project homepage: http://www.postronic.org/h3/software/sw-knack.html
 